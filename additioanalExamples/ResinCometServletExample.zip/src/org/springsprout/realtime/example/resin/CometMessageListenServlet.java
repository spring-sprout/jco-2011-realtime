package org.springsprout.realtime.example.resin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.caucho.servlet.comet.CometController;
import com.caucho.servlet.comet.GenericCometServlet;

@SuppressWarnings("serial")
public class CometMessageListenServlet extends GenericCometServlet {

    @Override
    public boolean service(ServletRequest request, ServletResponse response, 
            CometController cometController) throws IOException, ServletException {
        
        // 메시지 청취자를 등록
        return MessageListener.register(cometController);
    }

    @Override
    public boolean resume(ServletRequest request, ServletResponse response,
            CometController cometController) throws IOException, ServletException {
        
        String message = (String) cometController.getAttribute("message");
        if(message != null) {
            response.setContentType("application/json; charset=utf-8");
            response.getWriter().println("{\"message\":\"" + message.trim() + "\"}");
            response.getWriter().flush();
        }
        
        return false;
    }

}
