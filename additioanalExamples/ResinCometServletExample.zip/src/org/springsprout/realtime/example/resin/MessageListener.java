package org.springsprout.realtime.example.resin;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import com.caucho.servlet.comet.CometController;

public class MessageListener  {

    private static final BlockingQueue<String> messageQueue = new LinkedBlockingQueue<String>();
    private static final ThreadPoolExecutor executor = new ThreadPoolExecutor(
            10, 10, 120L, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>(10));    
    
    public static boolean register(CometController cometController) {
        try {
            executor.execute(new CometControllerWaker(cometController));
        } catch (Exception e) {
            return false;
        }
        
        return true;
    }
    
    public static void messageSend(String message) {
        messageQueue.add(message);
    }
    
    static class CometControllerWaker implements Runnable {
        private final CometController cometController;
        
        public CometControllerWaker(CometController cometController) {
            this.cometController = cometController;
        }
        
        @Override
        public void run() {
            try {
                cometController.setAttribute("message", messageQueue.poll(2 * 60 * 1000, TimeUnit.MILLISECONDS));
                cometController.wake();
            } catch (InterruptedException e) {
                // 무시
            }
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime
                    * result
                    + ((cometController == null) ? 0 : cometController
                            .hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            CometControllerWaker other = (CometControllerWaker) obj;
            if (cometController == null) {
                if (other.cometController != null)
                    return false;
            } else if (!cometController.equals(other.cometController))
                return false;
            return true;
        }
        
    }

}