package org.springsprout.realtime.example.jsr315;

import java.io.IOException;

import javax.servlet.AsyncContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
public class AsyncMessageListenServlet extends HttpServlet {
    
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        final AsyncContext asyncContext = request.startAsync();
        asyncContext.setTimeout(2 * 60 * 1000);
        
        MessageListener.register(asyncContext);
        
    }
    
}
