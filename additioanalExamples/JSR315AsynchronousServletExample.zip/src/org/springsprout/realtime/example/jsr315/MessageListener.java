package org.springsprout.realtime.example.jsr315;

import java.io.IOException;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.servlet.AsyncContext;
import javax.servlet.http.HttpServletResponse;

public class MessageListener  {

    private static final BlockingQueue<String> messageQueue = new LinkedBlockingQueue<String>();
    private static final ThreadPoolExecutor executor = new ThreadPoolExecutor(
            10, 10, 120L, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>(10));    
    
    public static boolean register(AsyncContext asyncContext) {
        try {
            executor.execute(new AsyncContextComplater(asyncContext));
        } catch (Exception e) {
            return false;
        }
        
        return true;
    }
    
    public static void messageSend(String message) {
        messageQueue.add(message);
    }
    
    static class AsyncContextComplater implements Runnable {
        private final AsyncContext asyncContext;
        
        public AsyncContextComplater(AsyncContext asyncContext) {
            this.asyncContext = asyncContext;
        }
        
        @Override
        public void run() {
            try {
                String message = messageQueue.poll(asyncContext.getTimeout(), TimeUnit.MILLISECONDS);
                if(message == null) message = "";
                
                HttpServletResponse response = (HttpServletResponse) asyncContext.getResponse();
                if(response != null) {
                    response.setContentType("application/json; charset=utf-8");
                    response.getWriter().println("{\"message\":\"" + message.trim() + "\"}");
                    response.getWriter().flush();
                }
                
                asyncContext.complete();
            } catch (InterruptedException e) {
                asyncContext.complete();
            } catch (IOException e) {
                asyncContext.complete();
            }
        }

    }

}